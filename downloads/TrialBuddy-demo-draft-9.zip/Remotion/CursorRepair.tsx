import React from 'react';
import {AbsoluteFill, CanvasImage, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Audio, Video} from '@remotion/media';
import track from '../public/cursor-track-v9.json';

// A single foreground layer owns every repaired hover. It always appears AFTER
// the synthetic account-name layer; no name mask can cover this pointer again.
const CursorForeground = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const point = track[frame];
  if (!point) return null;
  return <CanvasImage src={staticFile('cursor-v9/hand.png')} premountFor={fps}
    style={{position:'absolute', left:point.x, top:point.y, width:23, height:24}} />;
};
export const CursorRepair = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return <AbsoluteFill>
    {frame >= 314 && frame <= 808
      ? <CanvasImage src={staticFile(`cursor-v9/${String(frame).padStart(4,'0')}.png`)} premountFor={fps} style={{width:1280,height:720}} />
      : <Video src={staticFile('draft8.mp4')} muted premountFor={fps} style={{width:1280,height:720}} />}
    <CursorForeground />
    <Audio src={staticFile('draft8.mp4')} premountFor={fps} />
  </AbsoluteFill>;
};
